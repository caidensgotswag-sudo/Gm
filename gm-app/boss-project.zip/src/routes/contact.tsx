import { createFileRoute } from "@tanstack/react-router";
import { useState } from "react";
import { Mail, Phone, Calendar, Send, CheckCircle2 } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import { z } from "zod";
import { toast } from "sonner";
import { Toaster } from "@/components/ui/sonner";

export const Route = createFileRoute("/contact")({
  head: () => ({
    meta: [
      { title: "Contact — Book Your Free Business Audit | B.O.S.S." },
      { name: "description", content: "Book a free business audit with B.O.S.S. Email, call, or send a message — we respond within one business day." },
      { property: "og:title", content: "Contact B.O.S.S." },
      { property: "og:description", content: "Book your free business audit today." },
    ],
  }),
  component: Contact,
});

const schema = z.object({
  name: z.string().trim().min(1, "Name required").max(100),
  email: z.string().trim().email("Invalid email").max(255),
  company: z.string().trim().max(150).optional(),
  message: z.string().trim().min(10, "Tell us a bit more").max(1000),
});

function Contact() {
  const [submitted, setSubmitted] = useState(false);
  const [errors, setErrors] = useState<Record<string, string>>({});

  const onSubmit = (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const fd = new FormData(e.currentTarget);
    const data = Object.fromEntries(fd.entries());
    const result = schema.safeParse(data);
    if (!result.success) {
      const errs: Record<string, string> = {};
      result.error.issues.forEach((i) => { errs[i.path[0] as string] = i.message; });
      setErrors(errs);
      return;
    }
    setErrors({});
    setSubmitted(true);
    toast.success("Got it! We'll be in touch within one business day.");
  };

  return (
    <SiteLayout>
      <Toaster />
      <section className="bg-primary py-20 text-primary-foreground">
        <div className="mx-auto max-w-7xl px-6">
          <span className="text-xs font-bold uppercase tracking-widest text-accent">Contact</span>
          <h1 className="mt-3 font-display text-5xl md:text-6xl">Book your free audit.</h1>
          <p className="mt-4 max-w-xl text-lg text-primary-foreground/70">
            One conversation. Real numbers. Zero pressure.
          </p>
        </div>
      </section>

      <section className="bg-background py-20">
        <div className="mx-auto grid max-w-6xl gap-12 px-6 lg:grid-cols-[1fr_1.5fr]">
          <div className="space-y-6">
            <div className="border-l-2 border-accent bg-secondary p-6">
              <Phone className="h-6 w-6 text-accent" />
              <div className="mt-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Phone</div>
              <a href="tel:5551234567" className="mt-1 block text-lg font-bold">(555) 123-4567</a>
            </div>
            <div className="border-l-2 border-accent bg-secondary p-6">
              <Mail className="h-6 w-6 text-accent" />
              <div className="mt-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Email</div>
              <a href="mailto:hello@bossconsulting.com" className="mt-1 block text-lg font-bold">hello@bossconsulting.com</a>
            </div>
            <div className="border-l-2 border-accent bg-secondary p-6">
              <Calendar className="h-6 w-6 text-accent" />
              <div className="mt-3 text-xs font-bold uppercase tracking-wider text-muted-foreground">Book a call</div>
              <a href="#" className="mt-1 block text-lg font-bold underline">Schedule on our calendar →</a>
            </div>
          </div>

          <div className="bg-primary p-8 text-primary-foreground md:p-12">
            {submitted ? (
              <div className="flex h-full flex-col items-center justify-center text-center">
                <CheckCircle2 className="h-16 w-16 text-accent" />
                <h3 className="mt-6 font-display text-3xl">Message received.</h3>
                <p className="mt-3 text-primary-foreground/70">We'll reply within one business day.</p>
              </div>
            ) : (
              <form onSubmit={onSubmit} className="space-y-5">
                <h2 className="font-display text-3xl">Send us a message</h2>
                <Field label="Name" name="name" error={errors.name} />
                <Field label="Email" name="email" type="email" error={errors.email} />
                <Field label="Company (optional)" name="company" error={errors.company} />
                <div>
                  <label className="text-xs font-bold uppercase tracking-wider text-primary-foreground/60">Message</label>
                  <textarea
                    name="message"
                    rows={5}
                    className="mt-2 w-full border border-primary-foreground/20 bg-transparent p-3 text-primary-foreground outline-none focus:border-accent"
                  />
                  {errors.message && <p className="mt-1 text-xs text-accent">{errors.message}</p>}
                </div>
                <button type="submit" className="inline-flex items-center gap-2 bg-accent px-8 py-4 text-sm font-bold uppercase tracking-wide text-accent-foreground hover:scale-105">
                  Send Message <Send className="h-4 w-4" />
                </button>
              </form>
            )}
          </div>
        </div>
      </section>
    </SiteLayout>
  );
}

function Field({ label, name, type = "text", error }: { label: string; name: string; type?: string; error?: string }) {
  return (
    <div>
      <label className="text-xs font-bold uppercase tracking-wider text-primary-foreground/60">{label}</label>
      <input
        type={type}
        name={name}
        className="mt-2 w-full border border-primary-foreground/20 bg-transparent p-3 text-primary-foreground outline-none focus:border-accent"
      />
      {error && <p className="mt-1 text-xs text-accent">{error}</p>}
    </div>
  );
}
