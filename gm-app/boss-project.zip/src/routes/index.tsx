import { createFileRoute, Link } from "@tanstack/react-router";
import { ArrowRight, TrendingDown, Zap, CreditCard, Users, CheckCircle2, Quote } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";
import hero from "@/assets/hero.jpg";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "B.O.S.S. — Cut Costs. Increase Profit. Run Smarter." },
      { name: "description", content: "Business One Stop Shop. Consulting that cuts costs, streamlines operations, and grows your bottom line. Get a free business audit." },
      { property: "og:title", content: "B.O.S.S. — Cut Costs. Increase Profit. Run Smarter." },
      { property: "og:description", content: "Your One Stop Shop for Business Efficiency. Free audit available." },
    ],
  }),
  component: Home,
});

const services = [
  { icon: TrendingDown, title: "Cost Reduction", desc: "Audit every line item. Eliminate waste. Renegotiate vendors." },
  { icon: Zap, title: "Efficiency Optimization", desc: "Streamline workflows and tech stack to scale without bloat." },
  { icon: CreditCard, title: "Credit Solutions", desc: "Build business credit and access capital on better terms." },
  { icon: Users, title: "Payroll & Back Office", desc: "Outsource the chaos. Run payroll, HR, and admin like a Fortune 500." },
];

const steps = [
  { n: "01", t: "Free Consultation", d: "We listen, learn your business, and identify where money is leaking." },
  { n: "02", t: "Business Audit", d: "Deep dive into your expenses, vendors, systems, and operations." },
  { n: "03", t: "Implementation & Savings", d: "We execute the plan and you start seeing real ROI within weeks." },
];

const reasons = [
  "We find hidden costs others miss",
  "We modernize and improve your systems",
  "We grow your bottom line, not just revenue",
  "Trusted advisor approach — we treat your money like ours",
];

function Home() {
  return (
    <SiteLayout>
      {/* HERO */}
      <section className="relative overflow-hidden bg-primary text-primary-foreground">
        <div
          className="absolute inset-0 opacity-40"
          style={{ backgroundImage: `url(${hero})`, backgroundSize: "cover", backgroundPosition: "right center" }}
        />
        <div className="absolute inset-0 bg-gradient-to-r from-primary via-primary/90 to-transparent" />
        <div className="relative mx-auto grid max-w-7xl gap-12 px-6 py-24 md:grid-cols-2 md:py-36">
          <div>
            <span className="inline-flex items-center gap-2 border border-accent/40 bg-accent/10 px-3 py-1 text-xs font-bold uppercase tracking-widest text-accent">
              <span className="h-1.5 w-1.5 rounded-full bg-accent" /> Business One Stop Shop
            </span>
            <h1 className="mt-6 text-balance font-display text-5xl leading-[0.95] md:text-7xl">
              Cut Costs.<br />
              Increase Profit.<br />
              <span className="text-accent">Run Smarter.</span>
            </h1>
            <p className="mt-6 max-w-lg text-lg text-primary-foreground/75">
              Your One Stop Shop for Business Efficiency. We help restaurants, retail, and service businesses uncover hidden savings and scale with confidence.
            </p>
            <div className="mt-10 flex flex-wrap gap-4">
              <Link
                to="/contact"
                className="group inline-flex items-center gap-2 bg-accent px-8 py-4 text-sm font-bold uppercase tracking-wide text-accent-foreground shadow-elegant transition-transform hover:scale-105"
              >
                Get a Free Business Audit
                <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
              </Link>
              <Link to="/services" className="inline-flex items-center gap-2 border border-primary-foreground/30 px-8 py-4 text-sm font-bold uppercase tracking-wide hover:bg-primary-foreground/10">
                Our Services
              </Link>
            </div>
            <div className="mt-12 grid grid-cols-3 gap-6 border-t border-primary-foreground/10 pt-8">
              {[["30%", "Avg. cost cut"], ["500+", "Clients served"], ["14d", "To first savings"]].map(([n, l]) => (
                <div key={l}>
                  <div className="font-display text-3xl text-accent">{n}</div>
                  <div className="mt-1 text-xs uppercase tracking-wider text-primary-foreground/60">{l}</div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* SERVICES */}
      <section className="bg-background py-24">
        <div className="mx-auto max-w-7xl px-6">
          <div className="flex flex-col items-start justify-between gap-6 md:flex-row md:items-end">
            <div>
              <span className="text-xs font-bold uppercase tracking-widest text-accent">What We Do</span>
              <h2 className="mt-3 font-display text-4xl md:text-5xl">Four ways we move the needle.</h2>
            </div>
            <Link to="/services" className="inline-flex items-center gap-2 text-sm font-bold uppercase tracking-wide hover:text-accent">
              All Services <ArrowRight className="h-4 w-4" />
            </Link>
          </div>
          <div className="mt-12 grid gap-px bg-border md:grid-cols-2 lg:grid-cols-4">
            {services.map((s) => (
              <div key={s.title} className="group bg-background p-8 transition-colors hover:bg-primary hover:text-primary-foreground">
                <s.icon className="h-10 w-10 text-accent" />
                <h3 className="mt-6 font-display text-xl">{s.title}</h3>
                <p className="mt-3 text-sm text-muted-foreground group-hover:text-primary-foreground/70">{s.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* HOW IT WORKS */}
      <section className="bg-secondary py-24">
        <div className="mx-auto max-w-7xl px-6">
          <span className="text-xs font-bold uppercase tracking-widest text-accent">Process</span>
          <h2 className="mt-3 font-display text-4xl md:text-5xl">How it works.</h2>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {steps.map((s) => (
              <div key={s.n} className="border-l-2 border-accent bg-background p-8 shadow-card">
                <div className="font-display text-5xl text-accent/30">{s.n}</div>
                <h3 className="mt-4 font-display text-xl">{s.t}</h3>
                <p className="mt-3 text-sm text-muted-foreground">{s.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* WHY US */}
      <section className="bg-background py-24">
        <div className="mx-auto grid max-w-7xl gap-16 px-6 md:grid-cols-2">
          <div>
            <span className="text-xs font-bold uppercase tracking-widest text-accent">Why B.O.S.S.</span>
            <h2 className="mt-3 font-display text-4xl md:text-5xl">We don't just advise. We deliver ROI.</h2>
            <p className="mt-6 text-muted-foreground">
              Most consultants hand you a slide deck and a bill. We embed with your team, fix what's broken, and stick around until the savings hit your bank account.
            </p>
          </div>
          <ul className="space-y-4">
            {reasons.map((r) => (
              <li key={r} className="flex items-start gap-4 border-b border-border pb-4">
                <CheckCircle2 className="mt-0.5 h-6 w-6 flex-shrink-0 text-accent" />
                <span className="font-medium">{r}</span>
              </li>
            ))}
          </ul>
        </div>
      </section>

      {/* TESTIMONIALS */}
      <section className="bg-primary py-24 text-primary-foreground">
        <div className="mx-auto max-w-7xl px-6">
          <span className="text-xs font-bold uppercase tracking-widest text-accent">Clients</span>
          <h2 className="mt-3 font-display text-4xl md:text-5xl">Real businesses. Real savings.</h2>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {[
              { q: "B.O.S.S. cut our food cost by 22% in 60 days. Game changer.", n: "Marcus T.", r: "Restaurant Owner" },
              { q: "They found $48k in annual savings I had no idea existed.", n: "Priya S.", r: "Retail CEO" },
              { q: "Finally a consultant that understands small business reality.", n: "Daniel R.", r: "Service Co. Founder" },
            ].map((t) => (
              <div key={t.n} className="border border-primary-foreground/10 bg-primary-foreground/5 p-8">
                <Quote className="h-8 w-8 text-accent" />
                <p className="mt-4 text-lg leading-relaxed">"{t.q}"</p>
                <div className="mt-6 border-t border-primary-foreground/10 pt-4">
                  <div className="font-bold">{t.n}</div>
                  <div className="text-sm text-primary-foreground/60">{t.r}</div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FINAL CTA */}
      <section className="bg-red-gradient py-24 text-accent-foreground">
        <div className="mx-auto max-w-4xl px-6 text-center">
          <h2 className="font-display text-5xl md:text-7xl">Stop Overpaying.<br />Start Scaling.</h2>
          <p className="mx-auto mt-6 max-w-xl text-lg text-accent-foreground/80">
            Book your free audit today. No commitment, no fluff — just clarity on where your money is going and how to keep more of it.
          </p>
          <Link to="/contact" className="mt-10 inline-flex items-center gap-2 bg-primary px-10 py-5 text-sm font-bold uppercase tracking-wide text-primary-foreground transition-transform hover:scale-105">
            Book Your Free Audit <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
