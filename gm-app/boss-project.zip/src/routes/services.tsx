import { createFileRoute, Link } from "@tanstack/react-router";
import { TrendingDown, Zap, CreditCard, Users, ArrowRight, Check } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/services")({
  head: () => ({
    meta: [
      { title: "Services — B.O.S.S. Business Consulting" },
      { name: "description", content: "Cost reduction, efficiency optimization, credit solutions, and payroll consulting for small to mid-sized businesses." },
      { property: "og:title", content: "Services — B.O.S.S." },
      { property: "og:description", content: "Four service lines built to cut costs and grow profit." },
    ],
  }),
  component: Services,
});

const services = [
  {
    icon: TrendingDown,
    title: "Cost Reduction Consulting",
    desc: "We audit every recurring expense — vendors, software, utilities, merchant fees, insurance — and renegotiate or replace what's costing you too much.",
    points: ["Vendor renegotiation", "Merchant processing audit", "Software stack consolidation", "Utility & telecom review"],
  },
  {
    icon: Zap,
    title: "Business Efficiency Optimization",
    desc: "Streamline operations, automate the busywork, and give your team systems that actually scale with you.",
    points: ["Workflow automation", "Tech stack overhaul", "SOP development", "KPI dashboards"],
  },
  {
    icon: CreditCard,
    title: "Credit Solutions",
    desc: "Build strong business credit and access the capital you need on better terms — without personal guarantees when possible.",
    points: ["Business credit building", "Funding strategy", "Lender introductions", "Credit profile cleanup"],
  },
  {
    icon: Users,
    title: "Payroll & Back Office Consulting",
    desc: "Run payroll, HR, and admin like a Fortune 500 — without the overhead. We set up the systems and the team to support them.",
    points: ["Payroll setup & migration", "HR compliance", "Bookkeeping coordination", "Back office staffing"],
  },
];

function Services() {
  return (
    <SiteLayout>
      <section className="bg-primary py-24 text-primary-foreground">
        <div className="mx-auto max-w-7xl px-6">
          <span className="text-xs font-bold uppercase tracking-widest text-accent">Services</span>
          <h1 className="mt-3 max-w-3xl font-display text-5xl md:text-6xl">Four service lines. One mission: more profit.</h1>
          <p className="mt-6 max-w-2xl text-lg text-primary-foreground/70">
            Pick one or bundle them all. Every engagement starts with a free business audit.
          </p>
        </div>
      </section>

      <section className="bg-background py-24">
        <div className="mx-auto max-w-7xl space-y-16 px-6">
          {services.map((s, i) => (
            <div key={s.title} className={`grid gap-12 md:grid-cols-2 md:items-center ${i % 2 ? "md:[&>div:first-child]:order-2" : ""}`}>
              <div>
                <s.icon className="h-12 w-12 text-accent" />
                <h2 className="mt-6 font-display text-3xl md:text-4xl">{s.title}</h2>
                <p className="mt-4 text-muted-foreground">{s.desc}</p>
                <ul className="mt-6 space-y-2">
                  {s.points.map((p) => (
                    <li key={p} className="flex items-center gap-3"><Check className="h-5 w-5 text-accent" /> {p}</li>
                  ))}
                </ul>
              </div>
              <div className="aspect-square bg-secondary p-12 shadow-card">
                <div className="flex h-full w-full items-center justify-center border border-dashed border-accent/40">
                  <s.icon className="h-32 w-32 text-accent/30" strokeWidth={1} />
                </div>
              </div>
            </div>
          ))}
        </div>
      </section>

      <section className="bg-red-gradient py-20 text-accent-foreground">
        <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-6 px-6 text-center md:flex-row md:text-left">
          <h2 className="font-display text-3xl md:text-4xl">Not sure where to start?</h2>
          <Link to="/contact" className="inline-flex items-center gap-2 bg-primary px-8 py-4 text-sm font-bold uppercase tracking-wide text-primary-foreground hover:scale-105">
            Book Free Audit <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
