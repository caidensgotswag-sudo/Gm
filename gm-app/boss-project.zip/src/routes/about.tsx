import { createFileRoute, Link } from "@tanstack/react-router";
import { Target, Heart, Award, ArrowRight } from "lucide-react";
import { SiteLayout } from "@/components/SiteLayout";

export const Route = createFileRoute("/about")({
  head: () => ({
    meta: [
      { title: "About — B.O.S.S. Trusted Business Advisors" },
      { name: "description", content: "B.O.S.S. is the Business One Stop Shop. We're trusted advisors helping small and mid-sized businesses cut costs and grow." },
      { property: "og:title", content: "About B.O.S.S." },
      { property: "og:description", content: "Trusted advisors for restaurants, retail, and service businesses." },
    ],
  }),
  component: About,
});

function About() {
  return (
    <SiteLayout>
      <section className="bg-primary py-24 text-primary-foreground">
        <div className="mx-auto max-w-4xl px-6">
          <span className="text-xs font-bold uppercase tracking-widest text-accent">About B.O.S.S.</span>
          <h1 className="mt-3 font-display text-5xl md:text-7xl">We're the partner small business owners wish they had years ago.</h1>
        </div>
      </section>

      <section className="bg-background py-24">
        <div className="mx-auto grid max-w-6xl gap-16 px-6 md:grid-cols-2">
          <div>
            <h2 className="font-display text-3xl">Our Story</h2>
            <p className="mt-4 text-muted-foreground">
              B.O.S.S. — Business One Stop Shop — was founded on a simple frustration: small business owners pay too much, work too hard, and get too little real help.
            </p>
            <p className="mt-4 text-muted-foreground">
              We built B.O.S.S. to be the consultant we wished we'd had — the one who actually rolls up their sleeves, finds the leaks, and stays until the work is done.
            </p>
          </div>
          <div>
            <h2 className="font-display text-3xl">Our Approach</h2>
            <p className="mt-4 text-muted-foreground">
              We don't sell hours. We sell outcomes. Every engagement is built around measurable savings and operational improvements you can feel in your bottom line within weeks — not quarters.
            </p>
          </div>
        </div>
      </section>

      <section className="bg-secondary py-24">
        <div className="mx-auto max-w-7xl px-6">
          <h2 className="font-display text-4xl">What we stand for.</h2>
          <div className="mt-12 grid gap-8 md:grid-cols-3">
            {[
              { icon: Target, t: "Results First", d: "If you don't save more than you pay us, we haven't done our job." },
              { icon: Heart, t: "Real Partnership", d: "We treat your business like ours. Honest, direct, in your corner." },
              { icon: Award, t: "Proven Playbook", d: "Hundreds of businesses, millions saved, repeatable systems." },
            ].map((v) => (
              <div key={v.t} className="border-t-2 border-accent bg-background p-8">
                <v.icon className="h-10 w-10 text-accent" />
                <h3 className="mt-4 font-display text-xl">{v.t}</h3>
                <p className="mt-2 text-sm text-muted-foreground">{v.d}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      <section className="bg-red-gradient py-20 text-accent-foreground">
        <div className="mx-auto flex max-w-5xl flex-col items-center justify-between gap-6 px-6 text-center md:flex-row md:text-left">
          <h2 className="font-display text-3xl md:text-4xl">Let's talk about your business.</h2>
          <Link to="/contact" className="inline-flex items-center gap-2 bg-primary px-8 py-4 text-sm font-bold uppercase tracking-wide text-primary-foreground hover:scale-105">
            Get In Touch <ArrowRight className="h-4 w-4" />
          </Link>
        </div>
      </section>
    </SiteLayout>
  );
}
