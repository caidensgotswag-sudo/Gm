import { Link } from "@tanstack/react-router";

export function Footer() {
  return (
    <footer className="border-t border-border bg-primary text-primary-foreground">
      <div className="mx-auto grid max-w-7xl gap-10 px-6 py-16 md:grid-cols-4">
        <div className="md:col-span-2">
          <div className="flex items-center gap-2 font-display text-2xl">
            <span className="flex h-9 w-9 items-center justify-center bg-accent">B</span>
            B.O.S.S.
          </div>
          <p className="mt-4 max-w-sm text-sm text-primary-foreground/70">
            Business One Stop Shop. We cut costs, streamline operations, and grow your bottom line.
          </p>
        </div>
        <div>
          <h4 className="mb-4 text-xs font-bold uppercase tracking-wider text-accent">Company</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/80">
            <li><Link to="/about">About</Link></li>
            <li><Link to="/services">Services</Link></li>
            <li><Link to="/contact">Contact</Link></li>
          </ul>
        </div>
        <div>
          <h4 className="mb-4 text-xs font-bold uppercase tracking-wider text-accent">Contact</h4>
          <ul className="space-y-2 text-sm text-primary-foreground/80">
            <li>hello@bossconsulting.com</li>
            <li>(555) 123-4567</li>
          </ul>
        </div>
      </div>
      <div className="border-t border-primary-foreground/10 px-6 py-6 text-center text-xs text-primary-foreground/50">
        © {new Date().getFullYear()} B.O.S.S. — Business One Stop Shop. All rights reserved.
      </div>
    </footer>
  );
}
